package mapa;

import grafico.PuntoTDA;

import java.util.List;

public class Mapa extends MapaBase{

	@Override
	public List<PuntoTDA> getAdyacentes(PuntoTDA ubicacion) {
		// TODO Auto-generated method stub
		return null;
	}

}
