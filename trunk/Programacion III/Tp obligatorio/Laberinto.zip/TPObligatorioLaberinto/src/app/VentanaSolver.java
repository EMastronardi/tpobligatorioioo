package app;

import javax.swing.JFrame;

public class VentanaSolver extends JFrame {

	public VentanaSolver() {
		
	}
}
